# 社用車予約ボード（Cloudflare Pages版）

Netlify上の「社用車予約ボード」をCloudflare Pages + Cloudflare Functions + KVで動くように移植したものです。
元のアプリはブラウザ内の一時ストレージ（`window.storage`）を使っていたため、そのままではCloudflareで動きません。
代わりに `/api/vehicles`・`/api/reservations` という2つのAPIエンドポイント（Cloudflare Functions）を用意し、
そのAPIがCloudflare KV（キーバリューストア）にデータを保存する構成にしています。

## 構成

```
fleet-booking-board/
├── public/
│   └── index.html          … アプリ本体（フロントエンド）
├── functions/
│   └── api/
│       ├── vehicles.js     … 車両データの読み書きAPI
│       └── reservations.js … 予約データの読み書きAPI
└── wrangler.toml            … Cloudflare Pages / KVの設定
```

## デプロイ手順

### 1. Wrangler CLIを用意

```bash
npm install -g wrangler
wrangler login
```

### 2. KV Namespaceを作成

```bash
wrangler kv namespace create FLEET_KV
```

実行すると以下のようなIDが表示されるので、`wrangler.toml` の `id = "REPLACE_WITH_YOUR_KV_NAMESPACE_ID"` を
実際のIDに書き換えてください。

```
[[kv_namespaces]]
binding = "FLEET_KV"
id = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

### 3. Pagesプロジェクトを作成してデプロイ

```bash
cd fleet-booking-board
wrangler pages deploy public --project-name=fleet-booking-board
```

初回はプロジェクト作成の確認が出ます。デプロイ後、`wrangler.toml` にKVバインディングが書いてあっても、
**Pagesプロジェクトの管理画面（Settings → Functions → KV namespace bindings）でも同じ紐付けを追加**してください。
（Pagesはダッシュボード側の設定が優先されるため、念のため両方設定しておくと確実です。）

- Cloudflareダッシュボード → Workers & Pages → 対象プロジェクト → Settings → Functions
- 「KV namespace bindings」で `FLEET_KV` という変数名で、先ほど作成したNamespaceを選択

設定後、再デプロイ（もしくは「Retry deployment」）すると反映されます。

### 4. Gitリポジトリ経由での自動デプロイ（おすすめ）

GitHubにこのフォルダをpushし、Cloudflareダッシュボードの「Workers & Pages → Create → Pages → Connect to Git」で
リポジトリを接続すると、push毎に自動デプロイされます。ビルド設定は以下でOKです。

- Build command: (空欄のまま)
- Build output directory: `public`

Functions（`functions/api/*.js`）はリポジトリ内に置いてあれば自動的に認識されます。

## アクセス制限について

元のNetlify版はパスワード保護（401）がかかっていました。同様の制限をかけたい場合は
**Cloudflare Access**（Zero Trust）が簡単です。ダッシュボードの「Zero Trust → Access → Applications」から
このPagesのドメインに対してメール認証やパスワード認証のポリシーを設定できます。無料プランでも少人数なら利用可能です。

## 動作確認

デプロイ後、発行されたURL（例: `https://fleet-booking-board.pages.dev`）にアクセスし、車両追加・予約作成が
正常にでき、リロードしてもデータが保持されていればOKです。
